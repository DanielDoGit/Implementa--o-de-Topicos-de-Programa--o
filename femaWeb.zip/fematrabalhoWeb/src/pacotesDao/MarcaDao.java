package pacotesDao;

import java.util.ArrayList;

import pacotebase.Carro;
import pacotebase.Marca;

public class MarcaDao {
	
	private ArrayList<Marca> listaMarca = new ArrayList<Marca>();
	
	public ArrayList<Marca> getRetornaListaMarca(){
		Marca c1 = new Marca();
		c1.setIdMarca(1);
		c1.setNomeMarca("Chevrolet");
		listaMarca.add(c1);
		
		Marca c2 = new Marca();
		c2.setIdMarca(2);
		c2.setNomeMarca("Fiat");
		listaMarca.add(c2);
		
		Marca c3 = new Marca();
		c3.setIdMarca(3);
		c3.setNomeMarca("Woksvagem");
		listaMarca.add(c3);
		
		return listaMarca;
	}

}
