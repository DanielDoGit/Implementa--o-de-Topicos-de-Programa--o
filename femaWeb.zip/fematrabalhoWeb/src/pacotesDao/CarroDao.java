package pacotesDao;

import java.util.ArrayList;

import pacotebase.Carro;

public class CarroDao {
	
	private ArrayList<Carro> listaCarro = new ArrayList<Carro>();
	
	public ArrayList<Carro> getRetornaListaCarro(){
		Carro c1 = new Carro();
		c1.setIdCarro(1);
		c1.setNomeDoCarro("Montana");
		listaCarro.add(c1);
		
		Carro c2 = new Carro();
		c2.setIdCarro(2);
		c2.setNomeDoCarro("Doblo");
		listaCarro.add(c2);
		
		Carro c3 = new Carro();
		c3.setIdCarro(3);
		c3.setNomeDoCarro("Gol");
		listaCarro.add(c3);
		
		return listaCarro;
	}

}
