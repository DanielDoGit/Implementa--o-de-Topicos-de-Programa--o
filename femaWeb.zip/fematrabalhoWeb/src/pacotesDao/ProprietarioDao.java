package pacotesDao;

import java.util.ArrayList;

import pacotebase.Proprietario;

public class ProprietarioDao {
	
	private ArrayList<Proprietario> listaProprietario = new ArrayList<Proprietario>();
	
	public ArrayList<Proprietario> getRetornaListaProprietario(){
		
		Proprietario p1 = new Proprietario();
		p1.setIdProprietario(1);
		p1.setNomeDoProprietario("Alex");
		listaProprietario.add(p1);
		
		Proprietario p2 = new Proprietario();
		p2.setIdProprietario(2);
		p2.setNomeDoProprietario("Fernando");
		listaProprietario.add(p2);
		
		Proprietario p3 = new Proprietario();
		p3.setIdProprietario(3);
		p3.setNomeDoProprietario("Lima Soares");
		listaProprietario.add(p3);
		
		return listaProprietario;
	}

}
