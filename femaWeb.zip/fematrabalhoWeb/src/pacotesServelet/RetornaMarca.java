package pacotesServelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pacotebase.Carro;
import pacotebase.Marca;
import pacotesDao.CarroDao;
import pacotesDao.MarcaDao;

/**
 * Servlet implementation class RetornaMarca
 */
@WebServlet("/RetornaMarca")
public class RetornaMarca extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetornaMarca() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		MarcaDao marcaDao = new MarcaDao();
		
		Marca marca1 = marcaDao.getRetornaListaMarca().get(0);
		Marca marca2 = marcaDao.getRetornaListaMarca().get(1);
		Marca marca3 = marcaDao.getRetornaListaMarca().get(2);
		
		StringBuilder builder = new StringBuilder();
		builder.append(
				    "<html>"
				+ "<body>"
				+ "<table border="+"1"+">"
					+"<tr>"
							+"<td>id</td>"
							+"<td>Marca</td>"
					+ "</tr>"
					+"<tr>"
							+"<td>"+marca1.getIdMarca()+"</td>"
							+"<td>"+marca1.getNomeMarca()+"</td>"
					+ "</tr>"
					+"<tr>"
							+"<td>"+marca2.getIdMarca()+"</td>"
							+"<td>"+marca2.getNomeMarca()+"</td>"
					+ "</tr>"
					+"<tr>"
						+"<td>"+marca3.getIdMarca()+"</td>"
						+"<td>"+marca3.getNomeMarca()+"</td>"
					+ "</tr>"
					
				
				+"</table>"
				+ "</body>"
				+ "</html>");
		
		
		
		
		response.getWriter().append(builder.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
