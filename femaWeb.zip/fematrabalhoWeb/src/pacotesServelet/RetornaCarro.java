package pacotesServelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pacotebase.Carro;
import pacotesDao.CarroDao;

/**
 * Servlet implementation class RetornaCarro
 */
@WebServlet("/RetornaCarro")
public class RetornaCarro extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetornaCarro() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		CarroDao carroDao = new CarroDao();
		
		Carro carro1 = carroDao.getRetornaListaCarro().get(0);
		Carro carro2 = carroDao.getRetornaListaCarro().get(1);
		Carro carro3 = carroDao.getRetornaListaCarro().get(2);
		
		StringBuilder builder = new StringBuilder();
		builder.append(
				    "<html>"
				+ "<body>"
				+ "<table border="+"1"+">"
					+"<tr>"
							+"<td>id</td>"
							+"<td>Nome Carro</td>"
					+ "</tr>"
					+"<tr>"
							+"<td>"+carro1.getIdCarro()+"</td>"
							+"<td>"+carro1.getNomeDoCarro()+"</td>"
					+ "</tr>"
					+"<tr>"
							+"<td>"+carro2.getIdCarro()+"</td>"
							+"<td>"+carro2.getNomeDoCarro()+"</td>"
					+ "</tr>"
					+"<tr>"
						+"<td>"+carro3.getIdCarro()+"</td>"
						+"<td>"+carro3.getNomeDoCarro()+"</td>"
					+ "</tr>"
					
				
				+"</table>"
				+ "</body>"
				+ "</html>");
		
		
		
		response.getWriter().append(builder.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
