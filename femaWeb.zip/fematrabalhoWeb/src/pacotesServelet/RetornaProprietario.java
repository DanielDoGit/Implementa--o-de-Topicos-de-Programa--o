package pacotesServelet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pacotebase.Marca;
import pacotesDao.MarcaDao;
import pacotesDao.ProprietarioDao;
import pacotebase.Proprietario;

/**
 * Servlet implementation class RetornaProprietario
 */
@WebServlet("/RetornaProprietario")
public class RetornaProprietario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetornaProprietario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProprietarioDao proprietarioDao = new ProprietarioDao();
		
		Proprietario proprietario1 = proprietarioDao.getRetornaListaProprietario().get(0);
		Proprietario proprietario2 = proprietarioDao.getRetornaListaProprietario().get(1);
		Proprietario proprietario3 = proprietarioDao.getRetornaListaProprietario().get(2);
		
		StringBuilder builder = new StringBuilder();
		builder.append(
				    "<html>"
				+ "<body>"
				+ "<table border="+"1"+">"
					+"<tr>"
							+"<td>id</td>"
							+"<td>Marca</td>"
					+ "</tr>"
					+"<tr>"
							+"<td>"+proprietario1.getIdProprietario()+"</td>"
							+"<td>"+proprietario1.getNomeDoProprietario()+"</td>"
					+ "</tr>"
					+"<tr>"
							+"<td>"+proprietario2.getIdProprietario()+"</td>"
							+"<td>"+proprietario2.getNomeDoProprietario()+"</td>"
					+ "</tr>"
					+"<tr>"
						+"<td>"+proprietario3.getIdProprietario()+"</td>"
						+"<td>"+proprietario3.getNomeDoProprietario()+"</td>"
					+ "</tr>"
					
				
				+"</table>"
				+ "</body>"
				+ "</html>");
		
		
		
		
		response.getWriter().append(builder.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
